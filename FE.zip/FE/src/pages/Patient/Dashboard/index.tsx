const DashboardPage = () => {
  return <h1>Patient Dashboard Page</h1>;
};

export default DashboardPage;
