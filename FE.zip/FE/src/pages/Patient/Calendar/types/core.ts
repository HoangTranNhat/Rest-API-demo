// TODO: Add more types
export type PatientDetailEvent = {
  event_id: number;
  title: string;
  dentist: string;
  treatement: string;
  start: Date;
  end: Date;
};
