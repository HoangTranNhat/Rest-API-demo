const ErrorPage = () => {
  return <h1>This is Error page</h1>;
};
export default ErrorPage;
