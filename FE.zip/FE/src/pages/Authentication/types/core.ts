export type AuthResponseType = {
  accessToken?: string;
  refreshToken?: string;
};
