import AuthLayout from "./components/AuthLayout";

const AuthenticationPage = () => <AuthLayout />;
export default AuthenticationPage;
