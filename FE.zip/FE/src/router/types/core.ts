type FormatUser = {
  firstName: string;
  lastName: string;
  id: string;
  role: string;
};

export type { FormatUser };
