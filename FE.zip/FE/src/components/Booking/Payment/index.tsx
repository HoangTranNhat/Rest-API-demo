const PaymentPage = () => {
  return <h1>Payment</h1>;
};

export default PaymentPage;
