const AppointmentNotes = () => {
  return <h1>Appointment Notes</h1>;
};

export default AppointmentNotes;
