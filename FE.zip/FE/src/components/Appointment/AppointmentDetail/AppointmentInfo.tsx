const AppointmentInfo = () => {
  return <h1>Appointment Info</h1>;
};

export default AppointmentInfo;
