import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './App.css';

function App() {
  const [name, setName] = useState('');
  const [price, setPrice] = useState('');
  const [fuelList, setFuelList] = useState([]);

  const handleSubmit = (e) => {
    e.preventDefault();
    axios.post('https://a671-118-69-182-144.ngrok-free.app/create', {
      name: name,
      price: price
    })
    .then(response => {
      console.log('Tạo thành công:', response.data);
      // Clear the form
      setName('');
      setPrice('');
      // Refresh the fuel list after creating a new item
      fetchFuelList();
    })
    .catch(error => {
      console.error('Có lỗi xảy ra:', error);
    });
  };

  const fetchFuelList = () => {
    axios.get('https://a671-118-69-182-144.ngrok-free.app/list')
    .then(response => {
      setFuelList(response.data);
      console.log('Danh sách xăng:', response.data);
    })
    .catch(error => {
      console.error('Có lỗi xảy ra:', error);
    });
  };

  useEffect(() => {
    fetchFuelList();
  }, []);

  return (
    <div className="container">
      <h2>Tạo Xăng Mới</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label>Tên xăng</label>
          <input 
            type="text" 
            value={name} 
            onChange={(e) => setName(e.target.value)} 
          />
        </div>
        <div className="form-group">
          <label>Giá</label>
          <input 
            type="text" 
            value={price} 
            onChange={(e) => setPrice(e.target.value)} 
          />
        </div>
        <button type="submit" className="create-button">Tạo</button>
      </form>
      <button className="view-button" onClick={fetchFuelList}>Xem danh sách xăng</button>
      {fuelList.length > 0 && (
        <div className="fuel-list">
          <h3>Danh sách xăng</h3>
          <ul>
            {fuelList.map((fuel, index) => (
              <li key={index}>{fuel.name} - {fuel.price}</li>
            ))}
          </ul>
        </div>
      )}
    </div>
  );
}

export default App;
