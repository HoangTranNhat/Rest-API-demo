import React, { Component, createRef } from "react";
import "../../css/loginstyle.css";
import getInformationLogin from "../../js/App.js";
import Footer from "../../componets/Footer.jsx";

export default class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            phoneNumber: "",
            password: "",  
        }; 
    }

    setParams = (event) => {
        this.setState({ [event.target.name]: event.target.value });
    }
    
    login = (event) => {
        event.preventDefault();
        
        const myHeaders = new Headers();
        myHeaders.append("Content-Type", "application/json");

        const raw = JSON.stringify({
            emailOrPhoneNumber: this.state.phoneNumber,
            password: this.state.password
        });

        const requestOptions = {
            method: "POST",
            headers: myHeaders,
            body: raw,
            redirect: "follow"
        };
    
        fetch("https://0bc9-2402-800-637d-be38-c1d1-b0b5-a3df-a4.ngrok-free.app/forbad/auth/signin", requestOptions)
        .then((response) => response.text())
        .then((result) => console.log(result))
        .catch((error) => console.error(error));
    }
    

    render() {
        return (
            <div>
                <p id="wrong-repass" className="text-danger text-bold fw-bolder"></p>
                <div className="header-login-form">
                    <div className="container d-flex align-items-center justify-content-between">
                        <div className="header-login-form-left">
                            <div className="logo-header-login">
                                <img src="asserts/img/logo-cau-long-dep-01.png" alt="Logo" />
                            </div>
                            <div className="name-page">
                                <p className="m-0">Đăng nhập</p>
                            </div>
                        </div>
                        <div className="header-login-form-right m-0">
                            <a href="Guest.jsx">
                                Trở về trang chủ <i className="fa-solid fa-arrow-right" />
                            </a>
                        </div>
                    </div>
                </div>
                <div className="login-form" id="Login-form">
                    <div className="login-left">
                        <img src="asserts/img/logo-cau-long-dep-01.png" alt="Logo" />
                    </div>
                    <div className="login-right">
                        <form onSubmit={this.login}>
                            <h1>Đăng nhập</h1>
                            <div className="name-phone d-flex">
                                <div className="input-box">
                                <input 
                                        type="text" 
                                        name="phoneNumber" 
                                        placeholder="Số điện thoại" 
                                        id="phoneNumber" 
                                        value={this.state.phoneNumber}
                                        onChange={this.setParams}
                                />
                                    <i className="fa-solid fa-user" />
                                    <p id="userName-error" className="text-danger"></p>
                                </div>
                            </div>
                            <div className="input-box">
                            <input 
                                    type="password" 
                                    name="password" 
                                    placeholder="Mật khẩu" 
                                    id="password" 
                                    value={this.state.password}
                                    onChange={this.setParams}
                                />
                                <i className="fa-solid fa-lock" />
                                <p id="email-error" className="text-danger"></p>
                            </div>
                            <div className="remember-forgot">
                                <label><input type="checkbox" />Nhớ mật khẩu</label>
                                <a href="#">Quên mật khẩu</a>
                             </div>
                            <p id="wrong-repass" className="text-danger text-bold fw-bolder"></p>
                            <div className="btn">
                                <button type="submit">Đăng nhập</button>
                            </div>
                            <div className="divider">
                                <span>OR</span>
                            </div>
                            <div className="login-with">
                                <div className="gmail">
                                    <button className="btn btn-danger p-2">
                                        <i className="fa-brands fa-google" /> Đăng nhập với Google
                                    </button>
                                </div>
                            </div>
                            <div className="register-link">
                                <p>
                                    Bạn chưa có tài khoản? <a href="Register.js">Đăng ký</a>
                                </p>
                            </div>
                        </form>
                    </div>
                </div>
                <Footer />
            </div>
        );
    }
}
