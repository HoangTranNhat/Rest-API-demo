# S8 - React Redux 

React Context API
- Provider: 1
- Consumers: nhiều

Redux: lib - npm package: redux
- store
- action: object {type: '', payload: ''}
- reducer


Multiple Reducers --> combined reducers
Add todo list reducer 


react
react-dom 
redux

react-redux: install package
HOC: Higher Order Component
