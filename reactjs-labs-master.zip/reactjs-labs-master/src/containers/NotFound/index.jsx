import React from 'react';
import PropTypes from 'prop-types';

NotFound.propTypes = {

};

function NotFound(props) {
  return (
    <div>
      <h1>Oops ... Not Found! :P</h1>
    </div>
  );
}

export default NotFound;