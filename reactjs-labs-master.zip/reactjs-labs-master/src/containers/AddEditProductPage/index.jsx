import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

class AddEditProductPage extends PureComponent {
  render() {
    return (
      <div>
        Add edit product page
      </div>
    );
  }
}

AddEditProductPage.propTypes = {

};

export default AddEditProductPage;