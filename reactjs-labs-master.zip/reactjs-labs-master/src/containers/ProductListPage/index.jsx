import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

class ProductListPage extends PureComponent {
  render() {
    return (
      <div>
        Product List Page
      </div>
    );
  }
}

ProductListPage.propTypes = {

};

export default ProductListPage;