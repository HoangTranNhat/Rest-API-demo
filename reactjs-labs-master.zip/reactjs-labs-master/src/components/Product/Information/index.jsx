import React, { PureComponent } from 'react';
import PropTypes from 'prop-types';

class Information extends PureComponent {
  render() {
    return (
      <div>
        <h2>Product Information</h2>

        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eius qui quibusdam suscipit, vitae minima sequi iste enim id laudantium deserunt dolore reiciendis fuga eligendi similique totam placeat mollitia assumenda quisquam.</p>
      </div>
    );
  }
}

Information.propTypes = {

};

export default Information;