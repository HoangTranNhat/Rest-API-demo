
// Counter
export const INCREMENT = 'increment'
export const DECREMENT = 'decrement'

// Hero
export const GET_HERO_LIST = 'GET_HERO_LIST';
export const GET_HERO_LIST_SUCCESS = 'GET_HERO_LIST_SUCCESS';
export const GET_HERO_LIST_FAILED = 'GET_HERO_LIST_FAILED';