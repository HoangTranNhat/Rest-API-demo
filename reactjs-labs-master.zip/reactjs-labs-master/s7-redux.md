# React Context API + Redux

Global state: Logged in user
Using React Context API to manage global state

App.js --> ContextAPI
|__ all components can access to global context



TodoContainer: ContextAPI
|__ TodoList
  |__ Todo    

