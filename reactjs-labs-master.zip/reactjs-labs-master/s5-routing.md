# S5 - Routing

Routing sample for a resource

Posts

- Listing: /posts (exact)
- Add: /posts/add
- Edit: /posts/:postId/edit
- Detail: /posts/:postId --> /posts/12345






Nested routing: 

- Listing: /




Routing
HomePage: /
AboutPage: /about
Contacts: /contacts
NotFound



Router
Route vs Switch

